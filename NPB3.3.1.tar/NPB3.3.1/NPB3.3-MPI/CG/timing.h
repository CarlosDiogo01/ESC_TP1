      integer t_total, t_conjg, t_rcomm, t_ncomm, t_last
      parameter (t_total=1, t_conjg=2, t_rcomm=3, t_ncomm=4, t_last=4)

      logical timeron
      common /timers/ timeron
